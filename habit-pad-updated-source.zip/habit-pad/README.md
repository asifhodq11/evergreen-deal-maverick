# Habit Pad - Gamified Productivity App

A modern, offline-first web application for task management, goal tracking, and gamified productivity. Built with React, TypeScript, and IndexedDB for reliable local storage.

## 🚀 Features

### Core Functionality
- **Task Management**: Create, edit, complete, and delete tasks with categories and priorities
- **Offline-First**: All data stored locally using IndexedDB - no internet required
- **Gamification**: Points system, levels, streaks, and achievements
- **Dashboard**: Beautiful overview with progress tracking and daily quotes
- **Categories**: Organize tasks with color-coded categories (Work, Personal, Health, Learning, Social)
- **Priority System**: Low, Medium, and High priority tasks with different point values
- **Due Dates**: Set and track task deadlines with overdue indicators

### Advanced Features
- **Search & Filter**: Find tasks by title, category, or priority
- **Progress Tracking**: Visual progress rings and completion statistics
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Data Export/Import**: Backup and restore your data as JSON files
- **Settings Management**: Customize app preferences and notifications

### User Interface
- **Modern Design**: Clean, professional interface with smooth animations
- **Navigation**: Intuitive sidebar navigation with multiple pages
- **Dark/Light Mode**: Theme switching capability
- **Mobile-Friendly**: Responsive design with touch-friendly interactions

## 🛠 Technology Stack

- **Frontend**: React 18 with JavaScript (JSX)
- **Styling**: Tailwind CSS + shadcn/ui components
- **Database**: IndexedDB via Dexie.js for offline storage
- **State Management**: Zustand for predictable state management
- **Build Tool**: Vite for fast development and optimized builds
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for date manipulation
- **Animations**: Framer Motion for smooth transitions

## 📁 Project Structure

```
habit-pad/
├── src/
│   ├── components/
│   │   ├── ui/              # shadcn/ui components
│   │   ├── Dashboard.jsx    # Main dashboard page
│   │   ├── TasksPage.jsx    # Task management page
│   │   ├── SettingsPage.jsx # Settings and data management
│   │   ├── Navigation.jsx   # Sidebar navigation
│   │   ├── AddTaskModal.jsx # Task creation modal
│   │   └── TaskList.jsx     # Task display component
│   ├── lib/
│   │   ├── database.js      # IndexedDB setup and utilities
│   │   └── store.js         # Zustand state management
│   ├── App.jsx              # Main application component
│   ├── App.css              # Global styles
│   └── main.jsx             # Application entry point
├── public/                  # Static assets
├── dist/                    # Production build output
└── package.json             # Dependencies and scripts
```

## 🎯 Core Features Implementation

### Database Schema
The app uses IndexedDB with the following tables:
- **tasks**: Task data with categories, priorities, and status
- **categories**: Predefined categories with colors and icons
- **userStats**: User level, points, streaks, and achievements
- **settings**: App preferences and configuration

### Task Management
- **CRUD Operations**: Full create, read, update, delete functionality
- **Status Tracking**: Pending, completed, and skipped states
- **Point System**: Automatic point calculation based on priority and completion timing
- **Atomic Operations**: Reliable database transactions prevent data loss

### Gamification System
- **Points**: Earned based on task priority (Low: 1pt, Medium: 2pts, High: 3pts)
- **Levels**: Automatic level progression every 100 points
- **Streaks**: Daily completion streak tracking
- **Early Completion Bonus**: 1.5x points for tasks completed before due date

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ and pnpm (or npm)
- Modern web browser with IndexedDB support

### Installation
1. Clone the repository
2. Install dependencies: `pnpm install`
3. Start development server: `pnpm run dev`
4. Open http://localhost:5173 in your browser

### Building for Production
```bash
pnpm run build
```
The built files will be in the `dist/` directory.

## 📱 Usage Guide

### Adding Tasks
1. Click "Add New Task" button
2. Fill in task details (title required)
3. Select category, priority, and due date
4. Click "Add Task" to save

### Managing Tasks
- **Complete**: Click the circle icon or use the dropdown menu
- **Delete**: Use the dropdown menu (soft delete with undo option)
- **Filter**: Use search bar and filter dropdowns
- **View**: Switch between All, Pending, and Completed tabs

### Data Management
- **Export**: Download all data as JSON backup file
- **Import**: Restore data from previously exported file
- **Settings**: Customize app preferences and notifications

## 🔧 Configuration

### Default Categories
- Work (Blue)
- Personal (Green)
- Health (Red)
- Learning (Purple)
- Social (Orange)

### Point System
- Low Priority: 1 point
- Medium Priority: 2 points
- High Priority: 3 points
- Early Completion Bonus: 1.5x multiplier

## 🛡 Data Privacy & Security

- **Local Storage**: All data stored locally in your browser
- **No Tracking**: No analytics or user tracking
- **Offline-First**: Works completely without internet connection
- **Data Control**: Full export/import capabilities for data portability

## 🎨 Design Principles

- **Offline-First**: Core functionality works without internet
- **Reliability**: Atomic database operations prevent data loss
- **Responsive**: Mobile-first design approach
- **Accessibility**: Keyboard navigation and screen reader support
- **Performance**: Optimized for smooth 60fps interactions

## 🔮 Future Enhancements

- Goals and milestones tracking
- Calendar integration with drag-and-drop
- Routine management and scheduling
- Achievement system with unlockable rewards
- Pomodoro timer integration
- Data synchronization across devices

## 📄 License

This project is open source and available under the MIT License.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues and enhancement requests.

---

**Habit Pad** - Transform your productivity with gamified task management! 🎯✨

