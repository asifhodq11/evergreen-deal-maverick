import { useState, useEffect } from 'react';
import { useGoalStore } from '../lib/store.js';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { 
  Plus, 
  Target, 
  Calendar, 
  CheckCircle2, 
  Circle, 
  MoreHorizontal,
  AlertCircle,
  Trophy,
  Clock
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu.jsx';
import AddGoalModal from './AddGoalModal.jsx';
import AddMilestoneModal from './AddMilestoneModal.jsx';
import { format, differenceInDays, isAfter, isBefore } from 'date-fns';

const GoalsPage = () => {
  const [showAddGoal, setShowAddGoal] = useState(false);
  const [showAddMilestone, setShowAddMilestone] = useState(false);
  const [selectedGoalId, setSelectedGoalId] = useState(null);
  const { goals, milestones, loadGoals, completeMilestone } = useGoalStore();

  useEffect(() => {
    loadGoals();
  }, [loadGoals]);

  const getGoalMilestones = (goalId) => {
    return milestones.filter(milestone => milestone.goalId === goalId);
  };

  const getGoalProgress = (goalId) => {
    const goalMilestones = getGoalMilestones(goalId);
    if (goalMilestones.length === 0) return 0;
    const completedCount = goalMilestones.filter(m => m.done).length;
    return (completedCount / goalMilestones.length) * 100;
  };

  const getGoalStatus = (goal) => {
    const progress = getGoalProgress(goal.id);
    const today = new Date();
    
    if (progress === 100) {
      return { status: 'completed', color: 'bg-green-100 text-green-800', label: 'Completed' };
    }
    
    if (goal.targetDate) {
      const targetDate = new Date(goal.targetDate);
      const daysLeft = differenceInDays(targetDate, today);
      
      if (daysLeft < 0) {
        return { status: 'overdue', color: 'bg-red-100 text-red-800', label: 'Overdue' };
      } else if (daysLeft <= 7) {
        return { status: 'urgent', color: 'bg-orange-100 text-orange-800', label: 'Due Soon' };
      }
    }
    
    return { status: 'active', color: 'bg-blue-100 text-blue-800', label: 'In Progress' };
  };

  const handleAddMilestone = (goalId) => {
    setSelectedGoalId(goalId);
    setShowAddMilestone(true);
  };

  const handleCompleteMilestone = async (milestoneId) => {
    try {
      await completeMilestone(milestoneId);
    } catch (error) {
      console.error('Failed to complete milestone:', error);
    }
  };

  const activeGoals = goals.filter(goal => getGoalProgress(goal.id) < 100);
  const completedGoals = goals.filter(goal => getGoalProgress(goal.id) === 100);

  const goalStats = {
    total: goals.length,
    active: activeGoals.length,
    completed: completedGoals.length,
    overdue: goals.filter(goal => {
      const status = getGoalStatus(goal);
      return status.status === 'overdue';
    }).length
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Goals</h1>
          <p className="text-gray-600">Set and track your long-term objectives</p>
        </div>
        <Button
          onClick={() => setShowAddGoal(true)}
          className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Goal
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-purple-600">{goalStats.total}</div>
            <p className="text-sm text-gray-600">Total Goals</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-600">{goalStats.active}</div>
            <p className="text-sm text-gray-600">Active</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">{goalStats.completed}</div>
            <p className="text-sm text-gray-600">Completed</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-red-600">{goalStats.overdue}</div>
            <p className="text-sm text-gray-600">Overdue</p>
          </CardContent>
        </Card>
      </div>

      {/* Goals Tabs */}
      <Tabs defaultValue="active" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">Active Goals ({activeGoals.length})</TabsTrigger>
          <TabsTrigger value="completed">Completed ({completedGoals.length})</TabsTrigger>
          <TabsTrigger value="all">All Goals ({goals.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          <GoalsList 
            goals={activeGoals} 
            milestones={milestones}
            onAddMilestone={handleAddMilestone}
            onCompleteMilestone={handleCompleteMilestone}
            getGoalMilestones={getGoalMilestones}
            getGoalProgress={getGoalProgress}
            getGoalStatus={getGoalStatus}
          />
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          <GoalsList 
            goals={completedGoals} 
            milestones={milestones}
            onAddMilestone={handleAddMilestone}
            onCompleteMilestone={handleCompleteMilestone}
            getGoalMilestones={getGoalMilestones}
            getGoalProgress={getGoalProgress}
            getGoalStatus={getGoalStatus}
          />
        </TabsContent>

        <TabsContent value="all" className="space-y-4">
          <GoalsList 
            goals={goals} 
            milestones={milestones}
            onAddMilestone={handleAddMilestone}
            onCompleteMilestone={handleCompleteMilestone}
            getGoalMilestones={getGoalMilestones}
            getGoalProgress={getGoalProgress}
            getGoalStatus={getGoalStatus}
          />
        </TabsContent>
      </Tabs>

      {/* Modals */}
      <AddGoalModal 
        open={showAddGoal} 
        onClose={() => setShowAddGoal(false)} 
      />
      <AddMilestoneModal 
        open={showAddMilestone} 
        onClose={() => setShowAddMilestone(false)}
        goalId={selectedGoalId}
      />
    </div>
  );
};

const GoalsList = ({ 
  goals, 
  milestones, 
  onAddMilestone, 
  onCompleteMilestone,
  getGoalMilestones,
  getGoalProgress,
  getGoalStatus 
}) => {
  if (goals.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Target className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <h3 className="text-lg font-semibold mb-2">No goals yet</h3>
          <p className="text-gray-600">Create your first goal to start tracking your progress!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {goals.map((goal) => {
        const goalMilestones = getGoalMilestones(goal.id);
        const progress = getGoalProgress(goal.id);
        const status = getGoalStatus(goal);
        
        return (
          <Card key={goal.id} className="overflow-hidden">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <CardTitle className="text-lg">{goal.title}</CardTitle>
                    <Badge className={status.color}>{status.label}</Badge>
                  </div>
                  {goal.description && (
                    <p className="text-gray-600 text-sm">{goal.description}</p>
                  )}
                  <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                    {goal.targetDate && (
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        Due {format(new Date(goal.targetDate), 'MMM d, yyyy')}
                      </div>
                    )}
                    <div className="flex items-center gap-1">
                      <Trophy className="h-4 w-4" />
                      {goalMilestones.filter(m => m.done).length} / {goalMilestones.length} milestones
                    </div>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => onAddMilestone(goal.id)}>
                      <Plus className="mr-2 h-4 w-4" />
                      Add Milestone
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            
            <CardContent className="pt-0">
              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Progress</span>
                  <span className="text-sm text-gray-600">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              {/* Milestones */}
              {goalMilestones.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-gray-700">Milestones</h4>
                  <div className="space-y-2">
                    {goalMilestones.map((milestone) => (
                      <div 
                        key={milestone.id} 
                        className="flex items-center gap-3 p-2 rounded-lg bg-gray-50"
                      >
                        <button
                          onClick={() => !milestone.done && onCompleteMilestone(milestone.id)}
                          disabled={milestone.done}
                          className="flex-shrink-0"
                        >
                          {milestone.done ? (
                            <CheckCircle2 className="h-4 w-4 text-green-600" />
                          ) : (
                            <Circle className="h-4 w-4 text-gray-400 hover:text-blue-600 cursor-pointer" />
                          )}
                        </button>
                        <div className="flex-1">
                          <p className={`text-sm ${milestone.done ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                            {milestone.title}
                          </p>
                          {milestone.dueAt && (
                            <p className="text-xs text-gray-500">
                              Due {format(new Date(milestone.dueAt), 'MMM d')}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {goalMilestones.length === 0 && (
                <div className="text-center py-4">
                  <p className="text-sm text-gray-500 mb-2">No milestones yet</p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => onAddMilestone(goal.id)}
                  >
                    <Plus className="mr-2 h-3 w-3" />
                    Add First Milestone
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default GoalsPage;

