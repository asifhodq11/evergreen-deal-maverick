import { useState } from 'react';
import { useTaskStore } from '../lib/store.js';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { 
  CheckCircle2, 
  Circle, 
  Clock, 
  Calendar, 
  Trash2, 
  MoreHorizontal,
  AlertCircle 
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu.jsx';
import { format, isToday, isPast, differenceInDays } from 'date-fns';

const TaskList = ({ tasks = [], showDate = true, compact = false }) => {
  const { completeTask, deleteTask, categories } = useTaskStore();
  const [completingTasks, setCompletingTasks] = useState(new Set());
  const [deletingTasks, setDeletingTasks] = useState(new Set());

  const handleCompleteTask = async (taskId) => {
    if (completingTasks.has(taskId)) return;
    
    setCompletingTasks(prev => new Set(prev).add(taskId));
    try {
      const points = await completeTask(taskId);
      // You could show a toast notification here with the points earned
      console.log(`Task completed! Earned ${points} points.`);
    } catch (error) {
      console.error('Failed to complete task:', error);
    } finally {
      setCompletingTasks(prev => {
        const newSet = new Set(prev);
        newSet.delete(taskId);
        return newSet;
      });
    }
  };

  const handleDeleteTask = async (taskId) => {
    if (deletingTasks.has(taskId)) return;
    
    setDeletingTasks(prev => new Set(prev).add(taskId));
    try {
      await deleteTask(taskId);
    } catch (error) {
      console.error('Failed to delete task:', error);
    } finally {
      setDeletingTasks(prev => {
        const newSet = new Set(prev);
        newSet.delete(taskId);
        return newSet;
      });
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 0: return 'bg-green-100 text-green-800 border-green-200';
      case 1: return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 2: return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityLabel = (priority) => {
    switch (priority) {
      case 0: return 'Low';
      case 1: return 'Medium';
      case 2: return 'High';
      default: return 'Unknown';
    }
  };

  const getStatusIcon = (task) => {
    const isCompleting = completingTasks.has(task.id);
    
    if (task.status === 1) {
      return <CheckCircle2 className="h-5 w-5 text-green-600" />;
    }
    
    if (isCompleting) {
      return <div className="h-5 w-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />;
    }
    
    return <Circle className="h-5 w-5 text-gray-400 hover:text-blue-600 cursor-pointer" />;
  };

  const getTaskCategory = (categoryId) => {
    return categories.find(cat => cat.id === categoryId);
  };

  const getDateInfo = (task) => {
    if (!task.dueAt) return null;
    
    const dueDate = new Date(task.dueAt);
    const daysDiff = differenceInDays(dueDate, new Date());
    
    if (isToday(dueDate)) {
      return { text: 'Today', color: 'text-blue-600', urgent: false };
    } else if (isPast(dueDate)) {
      return { text: 'Overdue', color: 'text-red-600', urgent: true };
    } else if (daysDiff === 1) {
      return { text: 'Tomorrow', color: 'text-orange-600', urgent: false };
    } else if (daysDiff <= 3) {
      return { text: `${daysDiff} days`, color: 'text-orange-600', urgent: false };
    } else {
      return { text: format(dueDate, 'MMM d'), color: 'text-gray-600', urgent: false };
    }
  };

  if (tasks.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        <Circle className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <p>No tasks yet. Add your first task to get started!</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {tasks.map((task) => {
        const category = getTaskCategory(task.categoryId);
        const dateInfo = getDateInfo(task);
        const isDeleting = deletingTasks.has(task.id);
        
        return (
          <Card 
            key={task.id} 
            className={`transition-all duration-200 hover:shadow-md ${
              task.status === 1 ? 'opacity-75 bg-green-50' : 'bg-white'
            } ${isDeleting ? 'opacity-50' : ''}`}
          >
            <CardContent className={`p-4 ${compact ? 'p-3' : ''}`}>
              <div className="flex items-start gap-3">
                {/* Status Icon */}
                <button
                  onClick={() => task.status === 0 && handleCompleteTask(task.id)}
                  disabled={task.status === 1 || completingTasks.has(task.id)}
                  className="mt-1 flex-shrink-0"
                >
                  {getStatusIcon(task)}
                </button>

                {/* Task Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <h3 className={`font-medium ${
                        task.status === 1 ? 'line-through text-gray-500' : 'text-gray-900'
                      }`}>
                        {task.title}
                      </h3>
                      
                      {task.description && (
                        <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                          {task.description}
                        </p>
                      )}
                      
                      {/* Task Meta Info */}
                      <div className="flex items-center gap-3 mt-2 flex-wrap">
                        {/* Priority Badge */}
                        <Badge variant="outline" className={getPriorityColor(task.priority)}>
                          {getPriorityLabel(task.priority)}
                        </Badge>
                        
                        {/* Category */}
                        {category && (
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <div 
                              className="w-2 h-2 rounded-full" 
                              style={{ backgroundColor: category.color }}
                            />
                            {category.name}
                          </div>
                        )}
                        
                        {/* Due Date */}
                        {dateInfo && (
                          <div className={`flex items-center gap-1 text-sm ${dateInfo.color}`}>
                            {dateInfo.urgent ? (
                              <AlertCircle className="h-3 w-3" />
                            ) : (
                              <Calendar className="h-3 w-3" />
                            )}
                            {dateInfo.text}
                          </div>
                        )}
                        
                        {/* Estimated Time */}
                        {task.estimatedMinutes && (
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <Clock className="h-3 w-3" />
                            {task.estimatedMinutes}m
                          </div>
                        )}
                        
                        {/* Points */}
                        <div className="text-sm font-medium text-blue-600">
                          +{task.points} pts
                        </div>
                      </div>
                    </div>

                    {/* Actions Menu */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {task.status === 0 && (
                          <DropdownMenuItem 
                            onClick={() => handleCompleteTask(task.id)}
                            disabled={completingTasks.has(task.id)}
                          >
                            <CheckCircle2 className="mr-2 h-4 w-4" />
                            Mark Complete
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem 
                          onClick={() => handleDeleteTask(task.id)}
                          disabled={isDeleting}
                          className="text-red-600"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default TaskList;

