import { useState, useEffect } from 'react';
import { useTaskStore, useGoalStore } from '../lib/store.js';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  CheckCircle2, 
  Circle, 
  Target,
  Clock,
  Plus
} from 'lucide-react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  startOfWeek, 
  endOfWeek, 
  eachDayOfInterval, 
  isSameMonth, 
  isSameDay, 
  addMonths, 
  subMonths,
  isToday,
  isBefore,
  parseISO
} from 'date-fns';

const CalendarPage = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const { tasks, loadTasks } = useTaskStore();
  const { goals, milestones, loadGoals } = useGoalStore();

  useEffect(() => {
    loadTasks();
    loadGoals();
  }, [loadTasks, loadGoals]);

  // Get calendar days for the current month
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart);
  const calendarEnd = endOfWeek(monthEnd);
  const calendarDays = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  // Get tasks and milestones for a specific date
  const getItemsForDate = (date) => {
    const dayTasks = tasks.filter(task => {
      if (!task.dueAt) return false;
      return isSameDay(new Date(task.dueAt), date);
    });

    const dayMilestones = milestones.filter(milestone => {
      if (!milestone.dueAt) return false;
      return isSameDay(new Date(milestone.dueAt), date);
    });

    return { tasks: dayTasks, milestones: dayMilestones };
  };

  // Get items for selected date
  const selectedDateItems = getItemsForDate(selectedDate);

  // Navigation functions
  const goToPreviousMonth = () => setCurrentDate(subMonths(currentDate, 1));
  const goToNextMonth = () => setCurrentDate(addMonths(currentDate, 1));
  const goToToday = () => {
    const today = new Date();
    setCurrentDate(today);
    setSelectedDate(today);
  };

  // Get priority color for tasks
  const getPriorityColor = (priority) => {
    switch (priority) {
      case 0: return 'bg-blue-100 text-blue-800';
      case 1: return 'bg-yellow-100 text-yellow-800';
      case 2: return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityLabel = (priority) => {
    switch (priority) {
      case 0: return 'Low';
      case 1: return 'Medium';
      case 2: return 'High';
      default: return 'Unknown';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Calendar</h1>
          <p className="text-gray-600">View your tasks and milestones in calendar format</p>
        </div>
        <Button
          onClick={goToToday}
          variant="outline"
          className="w-full sm:w-auto"
        >
          <CalendarIcon className="mr-2 h-4 w-4" />
          Today
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Calendar Grid */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">
                  {format(currentDate, 'MMMM yyyy')}
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToPreviousMonth}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToNextMonth}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Calendar Header */}
              <div className="grid grid-cols-7 gap-1 mb-2">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="p-2 text-center text-sm font-medium text-gray-500">
                    {day}
                  </div>
                ))}
              </div>

              {/* Calendar Days */}
              <div className="grid grid-cols-7 gap-1">
                {calendarDays.map(day => {
                  const dayItems = getItemsForDate(day);
                  const isCurrentMonth = isSameMonth(day, currentDate);
                  const isSelected = isSameDay(day, selectedDate);
                  const isCurrentDay = isToday(day);
                  const hasItems = dayItems.tasks.length > 0 || dayItems.milestones.length > 0;

                  return (
                    <button
                      key={day.toISOString()}
                      onClick={() => setSelectedDate(day)}
                      className={`
                        relative p-2 h-20 text-left border rounded-lg transition-colors
                        ${isSelected 
                          ? 'bg-blue-100 border-blue-300' 
                          : 'hover:bg-gray-50 border-gray-200'
                        }
                        ${!isCurrentMonth ? 'text-gray-400' : 'text-gray-900'}
                        ${isCurrentDay ? 'bg-blue-50 border-blue-200' : ''}
                      `}
                    >
                      <div className={`text-sm font-medium ${isCurrentDay ? 'text-blue-600' : ''}`}>
                        {format(day, 'd')}
                      </div>
                      
                      {/* Items indicators */}
                      {hasItems && (
                        <div className="absolute bottom-1 left-1 right-1 space-y-1">
                          {dayItems.tasks.slice(0, 2).map((task, index) => (
                            <div
                              key={task.id}
                              className={`h-1 rounded-full ${
                                task.status === 1 ? 'bg-green-400' : 
                                isBefore(new Date(task.dueAt), new Date()) ? 'bg-red-400' : 'bg-blue-400'
                              }`}
                            />
                          ))}
                          {dayItems.milestones.slice(0, 1).map((milestone, index) => (
                            <div
                              key={milestone.id}
                              className={`h-1 rounded-full ${
                                milestone.done ? 'bg-green-400' : 'bg-purple-400'
                              }`}
                            />
                          ))}
                          {(dayItems.tasks.length + dayItems.milestones.length) > 3 && (
                            <div className="text-xs text-gray-500 text-center">
                              +{(dayItems.tasks.length + dayItems.milestones.length) - 3}
                            </div>
                          )}
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Selected Date Details */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="h-5 w-5" />
                {format(selectedDate, 'EEEE, MMMM d')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Tasks for selected date */}
              {selectedDateItems.tasks.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Tasks</h4>
                  <div className="space-y-2">
                    {selectedDateItems.tasks.map(task => (
                      <div key={task.id} className="flex items-start gap-3 p-2 rounded-lg bg-gray-50">
                        {task.status === 1 ? (
                          <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                        ) : (
                          <Circle className="h-4 w-4 text-gray-400 mt-0.5 flex-shrink-0" />
                        )}
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm font-medium ${
                            task.status === 1 ? 'line-through text-gray-500' : 'text-gray-900'
                          }`}>
                            {task.title}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge className={getPriorityColor(task.priority)} variant="secondary">
                              {getPriorityLabel(task.priority)}
                            </Badge>
                            {task.estimatedMinutes && (
                              <div className="flex items-center gap-1 text-xs text-gray-500">
                                <Clock className="h-3 w-3" />
                                {task.estimatedMinutes}m
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Milestones for selected date */}
              {selectedDateItems.milestones.length > 0 && (
                <div>
                  <h4 className="font-medium text-gray-900 mb-2">Milestones</h4>
                  <div className="space-y-2">
                    {selectedDateItems.milestones.map(milestone => {
                      const goal = goals.find(g => g.id === milestone.goalId);
                      return (
                        <div key={milestone.id} className="flex items-start gap-3 p-2 rounded-lg bg-purple-50">
                          {milestone.done ? (
                            <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          ) : (
                            <Target className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                          )}
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm font-medium ${
                              milestone.done ? 'line-through text-gray-500' : 'text-gray-900'
                            }`}>
                              {milestone.title}
                            </p>
                            {goal && (
                              <p className="text-xs text-gray-500 mt-1">
                                Goal: {goal.title}
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* No items message */}
              {selectedDateItems.tasks.length === 0 && selectedDateItems.milestones.length === 0 && (
                <div className="text-center py-8">
                  <CalendarIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2">No items scheduled</h3>
                  <p className="text-gray-600 text-sm mb-4">
                    No tasks or milestones are scheduled for this date.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">This Month</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Total Tasks</span>
                  <span className="font-medium">
                    {tasks.filter(task => {
                      if (!task.dueAt) return false;
                      const taskDate = new Date(task.dueAt);
                      return isSameMonth(taskDate, currentDate);
                    }).length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Completed</span>
                  <span className="font-medium text-green-600">
                    {tasks.filter(task => {
                      if (!task.dueAt || task.status !== 1) return false;
                      const taskDate = new Date(task.dueAt);
                      return isSameMonth(taskDate, currentDate);
                    }).length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Milestones</span>
                  <span className="font-medium">
                    {milestones.filter(milestone => {
                      if (!milestone.dueAt) return false;
                      const milestoneDate = new Date(milestone.dueAt);
                      return isSameMonth(milestoneDate, currentDate);
                    }).length}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Overdue</span>
                  <span className="font-medium text-red-600">
                    {tasks.filter(task => {
                      if (!task.dueAt || task.status === 1) return false;
                      const taskDate = new Date(task.dueAt);
                      return isBefore(taskDate, new Date()) && isSameMonth(taskDate, currentDate);
                    }).length}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CalendarPage;

