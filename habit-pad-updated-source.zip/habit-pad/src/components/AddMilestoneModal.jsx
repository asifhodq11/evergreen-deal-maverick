import { useState } from 'react';
import { useGoalStore } from '../lib/store.js';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Textarea } from '@/components/ui/textarea.jsx';
import { Calendar } from '@/components/ui/calendar.jsx';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover.jsx';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog.jsx';
import { CalendarIcon, Flag } from 'lucide-react';
import { format } from 'date-fns';

const AddMilestoneModal = ({ open, onClose, goalId }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    dueAt: null
  });
  const [showCalendar, setShowCalendar] = useState(false);
  const { addMilestone, goals } = useGoalStore();

  const goal = goals.find(g => g.id === goalId);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !goalId) return;

    setIsLoading(true);
    try {
      await addMilestone({
        goalId,
        title: formData.title.trim(),
        description: formData.description.trim(),
        dueAt: formData.dueAt
      });
      
      // Reset form
      setFormData({
        title: '',
        description: '',
        dueAt: null
      });
      onClose();
    } catch (error) {
      console.error('Failed to add milestone:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    if (!isLoading) {
      setFormData({
        title: '',
        description: '',
        dueAt: null
      });
      onClose();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Flag className="h-5 w-5 text-blue-600" />
            Add Milestone
          </DialogTitle>
          <DialogDescription>
            {goal ? `Add a milestone to "${goal.title}"` : 'Add a new milestone to track progress.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="milestone-title">Title *</Label>
            <Input
              id="milestone-title"
              placeholder="Enter milestone title..."
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
              disabled={isLoading}
              required
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="milestone-description">Description</Label>
            <Textarea
              id="milestone-description"
              placeholder="Add more details about this milestone..."
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              disabled={isLoading}
              rows={2}
            />
          </div>

          {/* Due Date */}
          <div className="space-y-2">
            <Label>Due Date</Label>
            <Popover open={showCalendar} onOpenChange={setShowCalendar}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                  disabled={isLoading}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formData.dueAt ? (
                    format(formData.dueAt, 'PPP')
                  ) : (
                    <span>Pick a due date</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={formData.dueAt}
                  onSelect={(date) => {
                    setFormData(prev => ({ ...prev, dueAt: date }));
                    setShowCalendar(false);
                  }}
                  disabled={(date) => {
                    const today = new Date();
                    today.setHours(0, 0, 0, 0);
                    
                    // Don't allow dates before today
                    if (date < today) return true;
                    
                    // If goal has target date, don't allow dates after target date
                    if (goal?.targetDate) {
                      const targetDate = new Date(goal.targetDate);
                      targetDate.setHours(23, 59, 59, 999);
                      return date > targetDate;
                    }
                    
                    return false;
                  }}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            {goal?.targetDate && (
              <p className="text-xs text-gray-500">
                Goal target date: {format(new Date(goal.targetDate), 'PPP')}
              </p>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading || !formData.title.trim()}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              {isLoading ? 'Adding...' : 'Add Milestone'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddMilestoneModal;

