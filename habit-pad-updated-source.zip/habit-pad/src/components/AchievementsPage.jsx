import { useState, useEffect } from 'react';
import { useUserStore, useTaskStore, useGoalStore } from '../lib/store.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Progress } from '@/components/ui/progress.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { 
  Trophy, 
  Star, 
  Target, 
  Zap, 
  Calendar, 
  CheckCircle2,
  Lock,
  Crown,
  Award,
  Flame
} from 'lucide-react';

const AchievementsPage = () => {
  const { stats, loadStats } = useUserStore();
  const { tasks } = useTaskStore();
  const { goals } = useGoalStore();

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  // Define achievement categories and criteria
  const achievementCategories = {
    tasks: {
      name: 'Task Master',
      icon: CheckCircle2,
      color: 'text-blue-600',
      achievements: [
        {
          id: 'first_task',
          title: 'Getting Started',
          description: 'Complete your first task',
          icon: CheckCircle2,
          requirement: 1,
          current: stats?.tasksCompleted || 0,
          points: 10,
          rarity: 'common'
        },
        {
          id: 'task_10',
          title: 'Task Warrior',
          description: 'Complete 10 tasks',
          icon: Target,
          requirement: 10,
          current: stats?.tasksCompleted || 0,
          points: 50,
          rarity: 'common'
        },
        {
          id: 'task_50',
          title: 'Productivity Pro',
          description: 'Complete 50 tasks',
          icon: Star,
          requirement: 50,
          current: stats?.tasksCompleted || 0,
          points: 200,
          rarity: 'rare'
        },
        {
          id: 'task_100',
          title: 'Task Master',
          description: 'Complete 100 tasks',
          icon: Crown,
          requirement: 100,
          current: stats?.tasksCompleted || 0,
          points: 500,
          rarity: 'epic'
        }
      ]
    },
    streaks: {
      name: 'Consistency',
      icon: Flame,
      color: 'text-orange-600',
      achievements: [
        {
          id: 'streak_3',
          title: 'On Fire',
          description: 'Maintain a 3-day streak',
          icon: Flame,
          requirement: 3,
          current: stats?.currentStreak || 0,
          points: 25,
          rarity: 'common'
        },
        {
          id: 'streak_7',
          title: 'Week Warrior',
          description: 'Maintain a 7-day streak',
          icon: Calendar,
          requirement: 7,
          current: stats?.longestStreak || 0,
          points: 75,
          rarity: 'uncommon'
        },
        {
          id: 'streak_30',
          title: 'Monthly Master',
          description: 'Maintain a 30-day streak',
          icon: Trophy,
          requirement: 30,
          current: stats?.longestStreak || 0,
          points: 300,
          rarity: 'rare'
        },
        {
          id: 'streak_100',
          title: 'Unstoppable',
          description: 'Maintain a 100-day streak',
          icon: Crown,
          requirement: 100,
          current: stats?.longestStreak || 0,
          points: 1000,
          rarity: 'legendary'
        }
      ]
    },
    levels: {
      name: 'Experience',
      icon: Star,
      color: 'text-purple-600',
      achievements: [
        {
          id: 'level_5',
          title: 'Rising Star',
          description: 'Reach level 5',
          icon: Star,
          requirement: 5,
          current: stats?.level || 1,
          points: 100,
          rarity: 'common'
        },
        {
          id: 'level_10',
          title: 'Experienced',
          description: 'Reach level 10',
          icon: Award,
          requirement: 10,
          current: stats?.level || 1,
          points: 250,
          rarity: 'uncommon'
        },
        {
          id: 'level_25',
          title: 'Expert',
          description: 'Reach level 25',
          icon: Trophy,
          requirement: 25,
          current: stats?.level || 1,
          points: 500,
          rarity: 'rare'
        },
        {
          id: 'level_50',
          title: 'Legendary',
          description: 'Reach level 50',
          icon: Crown,
          requirement: 50,
          current: stats?.level || 1,
          points: 1500,
          rarity: 'legendary'
        }
      ]
    },
    goals: {
      name: 'Goal Achiever',
      icon: Target,
      color: 'text-green-600',
      achievements: [
        {
          id: 'first_goal',
          title: 'Visionary',
          description: 'Create your first goal',
          icon: Target,
          requirement: 1,
          current: goals?.length || 0,
          points: 20,
          rarity: 'common'
        },
        {
          id: 'goal_complete',
          title: 'Goal Crusher',
          description: 'Complete your first goal',
          icon: CheckCircle2,
          requirement: 1,
          current: goals?.filter(g => {
            // Calculate if goal is completed (simplified)
            return false; // This would need proper milestone completion logic
          }).length || 0,
          points: 100,
          rarity: 'uncommon'
        }
      ]
    }
  };

  // Get rarity color
  const getRarityColor = (rarity) => {
    switch (rarity) {
      case 'common': return 'bg-gray-100 text-gray-800 border-gray-300';
      case 'uncommon': return 'bg-green-100 text-green-800 border-green-300';
      case 'rare': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'epic': return 'bg-purple-100 text-purple-800 border-purple-300';
      case 'legendary': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      default: return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  // Get all achievements
  const allAchievements = Object.values(achievementCategories).flatMap(category => 
    category.achievements.map(achievement => ({
      ...achievement,
      category: category.name,
      categoryIcon: category.icon,
      categoryColor: category.color
    }))
  );

  // Filter achievements
  const unlockedAchievements = allAchievements.filter(a => a.current >= a.requirement);
  const lockedAchievements = allAchievements.filter(a => a.current < a.requirement);
  const inProgressAchievements = lockedAchievements.filter(a => a.current > 0);

  // Calculate total points
  const totalPointsEarned = unlockedAchievements.reduce((sum, a) => sum + a.points, 0);
  const totalPointsAvailable = allAchievements.reduce((sum, a) => sum + a.points, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Achievements</h1>
          <p className="text-gray-600">Track your progress and unlock rewards</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-yellow-600">{unlockedAchievements.length}</div>
            <p className="text-sm text-gray-600">Unlocked</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-600">{inProgressAchievements.length}</div>
            <p className="text-sm text-gray-600">In Progress</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-purple-600">{totalPointsEarned}</div>
            <p className="text-sm text-gray-600">Points Earned</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-gray-600">
              {Math.round((unlockedAchievements.length / allAchievements.length) * 100)}%
            </div>
            <p className="text-sm text-gray-600">Completion</p>
          </CardContent>
        </Card>
      </div>

      {/* Achievement Tabs */}
      <Tabs defaultValue="all" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All ({allAchievements.length})</TabsTrigger>
          <TabsTrigger value="unlocked">Unlocked ({unlockedAchievements.length})</TabsTrigger>
          <TabsTrigger value="progress">In Progress ({inProgressAchievements.length})</TabsTrigger>
          <TabsTrigger value="locked">Locked ({lockedAchievements.length - inProgressAchievements.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <AchievementGrid achievements={allAchievements} getRarityColor={getRarityColor} />
        </TabsContent>

        <TabsContent value="unlocked">
          <AchievementGrid achievements={unlockedAchievements} getRarityColor={getRarityColor} />
        </TabsContent>

        <TabsContent value="progress">
          <AchievementGrid achievements={inProgressAchievements} getRarityColor={getRarityColor} />
        </TabsContent>

        <TabsContent value="locked">
          <AchievementGrid 
            achievements={lockedAchievements.filter(a => a.current === 0)} 
            getRarityColor={getRarityColor} 
          />
        </TabsContent>
      </Tabs>

      {/* Categories Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {Object.entries(achievementCategories).map(([key, category]) => {
          const categoryAchievements = category.achievements;
          const unlockedCount = categoryAchievements.filter(a => a.current >= a.requirement).length;
          const totalCount = categoryAchievements.length;
          const progress = (unlockedCount / totalCount) * 100;

          return (
            <Card key={key}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <category.icon className={`h-5 w-5 ${category.color}`} />
                  {category.name}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{unlockedCount}/{totalCount}</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                  <div className="text-xs text-gray-500">
                    {Math.round(progress)}% complete
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};

const AchievementGrid = ({ achievements, getRarityColor }) => {
  if (achievements.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Trophy className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <h3 className="text-lg font-semibold mb-2">No achievements found</h3>
          <p className="text-gray-600">Keep working to unlock more achievements!</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {achievements.map((achievement) => {
        const isUnlocked = achievement.current >= achievement.requirement;
        const progress = Math.min((achievement.current / achievement.requirement) * 100, 100);
        const Icon = achievement.icon;

        return (
          <Card 
            key={achievement.id} 
            className={`relative overflow-hidden ${
              isUnlocked ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200' : ''
            }`}
          >
            <CardContent className="p-4">
              {/* Rarity Badge */}
              <div className="flex justify-between items-start mb-3">
                <Badge className={`${getRarityColor(achievement.rarity)} text-xs font-medium border`}>
                  {achievement.rarity}
                </Badge>
                {isUnlocked && (
                  <Trophy className="h-4 w-4 text-yellow-600" />
                )}
              </div>

              {/* Icon and Title */}
              <div className="flex items-center gap-3 mb-3">
                <div className={`p-2 rounded-lg ${
                  isUnlocked ? 'bg-yellow-100' : 'bg-gray-100'
                }`}>
                  {isUnlocked ? (
                    <Icon className="h-6 w-6 text-yellow-600" />
                  ) : (
                    <Lock className="h-6 w-6 text-gray-400" />
                  )}
                </div>
                <div className="flex-1">
                  <h3 className={`font-semibold ${
                    isUnlocked ? 'text-gray-900' : 'text-gray-500'
                  }`}>
                    {achievement.title}
                  </h3>
                  <p className="text-xs text-gray-500">{achievement.category}</p>
                </div>
              </div>

              {/* Description */}
              <p className={`text-sm mb-3 ${
                isUnlocked ? 'text-gray-700' : 'text-gray-500'
              }`}>
                {achievement.description}
              </p>

              {/* Progress */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Progress</span>
                  <span className={isUnlocked ? 'text-green-600 font-medium' : 'text-gray-600'}>
                    {achievement.current}/{achievement.requirement}
                  </span>
                </div>
                <Progress 
                  value={progress} 
                  className={`h-2 ${isUnlocked ? 'bg-yellow-100' : ''}`}
                />
              </div>

              {/* Points */}
              <div className="flex justify-between items-center mt-3 pt-3 border-t border-gray-100">
                <span className="text-xs text-gray-500">Reward</span>
                <div className="flex items-center gap-1">
                  <Star className="h-3 w-3 text-yellow-500" />
                  <span className="text-sm font-medium text-gray-700">
                    {achievement.points} pts
                  </span>
                </div>
              </div>

              {/* Unlocked overlay */}
              {isUnlocked && (
                <div className="absolute top-2 right-2">
                  <div className="bg-green-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                    Unlocked!
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default AchievementsPage;

